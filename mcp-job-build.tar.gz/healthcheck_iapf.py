#!/usr/bin/env python3
"""
Script rapide pour la commande healthcheck_iapf
Usage: python healthcheck_iapf.py
"""
import sys
from mcp_cockpit.cli import main

if __name__ == '__main__':
    sys.exit(main())
