"""
MCP Central Cockpit - IA Process Factory
READ-ONLY monitoring + WRITE contrôlé sur HUB ORION
"""
__version__ = "1.0.0"
